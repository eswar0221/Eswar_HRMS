import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-addclient',
  templateUrl: './addclient.component.html',
  styleUrls: ['./addclient.component.css']
})
export class AddclientComponent implements OnInit {
  file: File;
  ServiceData = {
    firstname : "",
    username : "",
    password : "",
    employeeid : "",
    company : "",
    phone : "",
    lastname : "",
    email : "",
    cpassword : "",
    designation : "",
  
  }

  back(){
    this.router.navigate(['Admin/clients'])
  }
  constructor(private router:Router) { }

  ngOnInit() {
  }

}
