import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'app-clients',
  templateUrl: './clients.component.html',
  styleUrls: ['./clients.component.css']
})
export class ClientsComponent implements OnInit {
  tmp:boolean=true;
  myform: FormGroup;
  
  data:any=[{name:"eswar",clientid:12,contact_person:"xyz",email:"abc@gmail.com" ,mobile:899997567,status:"failed",action:"abc" },
  {name:"eswar",clientid:12,contact_person:"xyz",email:"abc@gmail.com" ,mobile:899997567,status:"failed",action:"abc" },
  {name:"eswar",clientid:12,contact_person:"xyz",email:"abc@gmail.com" ,mobile:899997567,status:"failed",action:"abc" },
  {name:"eswar",clientid:12,contact_person:"xyz",email:"abc@gmail.com" ,mobile:899997567,status:"failed",action:"abc" },
 
  {name:"eswar",clientid:12,contact_person:"xyz",email:"abc@gmail.com" ,mobile:899997567,action:"abc" }]

  constructor(private router:Router) { }
  addclient(){
    this.router.navigate(['Admin/addclient'])
  }
  ngOnInit() {
  }
  back(){
    this.router.navigate(['Admin/editclient'])
  }
  tmpe1(){
    this.tmp=true
  }

  tmpe(){
    this.tmp=false
  }

}
